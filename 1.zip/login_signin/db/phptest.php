<?php
$connect=mysqli_connect("localhost","root","","user") or die(mysqli_error($connection))
?>